# phishing-paypal-2020
phishing paypal ,French, English

à vos risque

open 

 admin

config.php

usernam = admin

password = admin

# Contact

Whatsapp: +1 336 415 3487 

Instagram, skype : hakanonymos

hakanonymos@hotmail.com


